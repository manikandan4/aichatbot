// src/components/ChatMessage.js

import React from 'react';
import { ListItem, Paper } from '@mui/material';
import ReactMarkdown from 'react-markdown';
import { useTheme } from '@mui/material/styles';

function ChatMessage({ message }) {
  const isUserMessage = message.role === 'user';
  const displayMessage = message.content;
  const theme = useTheme();

  return (
    <ListItem
    sx={{
      display: 'flex',
      justifyContent: isUserMessage ? 'flex-end' : 'flex-start',
      mb: 1,
    }}>
      <Paper
        sx={{
          p: 2,
          minWidth: '100px',
          bgcolor: isUserMessage ? theme.palette.primary.main : theme.palette.secondary.main,
          color:isUserMessage ? theme.palette.primary.contrastText : theme.palette.secondary.contrastText,
          borderRadius: 8,
          wordBreak: 'break-word',
          boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)', 
          fontSize: '14px', 
        }}
      >
        <ReactMarkdown>{displayMessage}</ReactMarkdown>
      </Paper>
    </ListItem>
  );
}

export default ChatMessage;
