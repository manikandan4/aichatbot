// src/components/Chat.js

import React, { useState } from 'react';
import axios from 'axios';
import { Box, TextField, Button, Typography, List, Alert } from '@mui/material';
import ChatMessage from './ChatMessage';
import FollowUpQuestion from './FollowUpQuestion';

function Chat() {
  const [query, setQuery] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const [followUpQuestions, setFollowUpQuestions] = useState([]);
  const [conversationCount, setConversationCount] = useState(0);
  const [limitReached, setLimitReached] = useState(false);

  const handleSend = async () => {
    if (!query.trim()) return;

    try {
      const response = await axios.post('http://localhost:8000/chat', {
        query,
        history: chatHistory,
        count: conversationCount,
      });

      if (response.data.count === 0) {
        setLimitReached(true);
        setQuery('');
        setChatHistory([]);
        setFollowUpQuestions([]);
        setConversationCount(0);
      } else {
        const assistantResponse = response.data.response;
        const updatedHistory = [...chatHistory, { role: 'user', content: query }, { role: 'assistant', content: assistantResponse }];
        setChatHistory(updatedHistory);
        setFollowUpQuestions(response.data.follow_up_questions);
        setConversationCount(response.data.count);
        setQuery('');
      }
    } catch (error) {
      console.error("Error sending query:", error);
    }
  };

  const handleFollowUpClick = async (question) => {
    setQuery(question);
    await handleSend();
  };

  const startNewChat = () => {
    setLimitReached(false);
    setChatHistory([]);
    setFollowUpQuestions([]);
    setConversationCount(0);
    setQuery('');
  };

  return (
    <Box sx={{ width: '100%', maxWidth: 600, mx: 'auto', mt: 4, p: 2, border: '1px solid #ddd', borderRadius: 2, boxShadow: 3 }}>
      <Typography variant="h6" align="center" gutterBottom>Chat with LLM</Typography>
      {limitReached && (
        <Alert severity="info" sx={{ mb: 2 }}>
          Conversation limit reached. Please start a new chat.
        </Alert>
      )}
      <List sx={{ height: 400, overflowY: 'auto', mb: 2 }}>
        {chatHistory.map((message, index) => (
          <ChatMessage key={index} message={message} />
        ))}
      </List>
      {!limitReached && (
        <>
          <Box sx={{ display: 'flex', gap: 1, mt: 2 }}>
            <TextField
              fullWidth
              variant="outlined"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type your message..."
            />
            <Button variant="contained" color="primary" onClick={handleSend}>Send</Button>
          </Box>
          {followUpQuestions.length > 0 && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle1">Follow-up Questions</Typography>
              {followUpQuestions.map((question, index) => (
                <FollowUpQuestion key={index} question={question} onClick={handleFollowUpClick} />
              ))}
            </Box>
          )}
        </>
      )}
      {limitReached && (
        <Button variant="contained" color="secondary" onClick={startNewChat}>
          Start New Chat
        </Button>
      )}
    </Box>
  );
}

export default Chat;
