// src/components/Footer.js

import React from 'react';
import { AppBar, Toolbar, Typography } from '@mui/material';

function Footer() {
  return (
    <AppBar position="static" sx={{ top: 'auto', bottom: 0}}>
      <Toolbar>
        <Typography variant="body1" align="center" sx={{ width: '100%' }}>
          © Manikandan Sadhasivam
        </Typography>
      </Toolbar>
    </AppBar>
  );
}

export default Footer;
