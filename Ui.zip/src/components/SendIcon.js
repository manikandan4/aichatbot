// SendIcon.js

import React from 'react';
import Button from '@mui/material/Button';
import SendIcon from '@mui/icons-material/Send';

const SendIconComponent = ({ onClick }) => {
  return (
    <Button
      variant="contained"
      color="primary"
      onClick={onClick}
      sx={{
        borderRadius: '20%', // Make the button circular
        minWidth: 0, // Reduce minimum width to fit the icon
        '&:hover': {
          backgroundColor: '#0078d4', // Lighter blue on hover
        },
      }}
    >
      <SendIcon />
    </Button>
  );
};

export default SendIconComponent;
