// src/components/FollowUpQuestion.js

import React from 'react';
import { Button } from '@mui/material';
import { useTheme } from '@mui/material/styles';

function FollowUpQuestion({ question, onClick }) {
  const theme = useTheme();
  const actualText = question.replace(/^\d+\.\s*/, '');
  return (
    <Button
      fullWidth
      variant="outlined"
      sx={{ mt: 0.5, 
        fontSize: '10px',
        bgcolor: theme.palette.secondary.light
      }}
      onClick={() => onClick(actualText)}
    >
      {actualText}
    </Button>
  );
}

export default FollowUpQuestion;
