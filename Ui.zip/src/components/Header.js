import React from 'react';
import { AppBar, Toolbar, Typography, IconButton } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu'; // Import the hamburger menu icon

function Header() {
  return (
    <AppBar position="static">
      <Toolbar>
        {/* Left section with Visa icon */}
        <img src="/ai.png" alt="AI Icon" style={{ width: '60px', height: 'auto', margin: '8px 0'  }} />

        <div style={{ flexGrow: 1 }}></div>

        {/* Right section with hamburger menu */}
        <IconButton edge="end" color="inherit" aria-label="menu">
          <MenuIcon />
        </IconButton>
      </Toolbar>
    </AppBar>
  );
}

export default Header;
