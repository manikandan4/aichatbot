// src/components/Chat.js

import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import {
  Box,
  TextField,
  Button,
  Typography,
  Alert,
  CircularProgress,
  Stack
} from '@mui/material';
import ChatMessage from './ChatMessage';
import FollowUpQuestion from './FollowUpQuestion';
import SendIconComponent from './SendIcon';

function Chat() {
  const [query, setQuery] = useState('');
  const [chatHistory, setChatHistory] = useState([{ role: 'assistant', content: 'How can i help you today ?' }]);
  const [followUpQuestions, setFollowUpQuestions] = useState([]);
  const [conversationCount, setConversationCount] = useState(0);
  const [limitReached, setLimitReached] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async () => {
    const hostname = process.env.REACT_APP_BACKEND_HOST;
    const port = process.env.REACT_APP_BACKEND_PORT;
    const baseUrl = 'http://' + hostname + ':' + port + '/chat'

    console.log(baseUrl)

    if (!query.trim()) return;

    try {
      setIsLoading(true);
      const response = await axios.post(baseUrl, {
        query,
        history: chatHistory,
        count: conversationCount,
      });

      if (response.data.count === 0) {
        setLimitReached(true);
        setQuery('');
        setChatHistory([]);
        setFollowUpQuestions([]);
        setConversationCount(0);
      } else {
        const assistantResponse = response.data.response;
        const updatedHistory = [
          ...chatHistory,
          { role: 'user', content: query },
          { role: 'assistant', content: assistantResponse },
        ];
        setChatHistory(updatedHistory);
        setFollowUpQuestions(response.data.follow_up_questions);
        setConversationCount(response.data.count);
        setQuery('');
      }
      setIsLoading(false);
    } catch (error) {
      console.error('Error sending query:', error);
    }
  };

  const handleFollowUpClick = async (question) => {
    setQuery(question);
    await handleSend();
  };

  const startNewChat = () => {
    setLimitReached(false);
    setChatHistory([]);
    setFollowUpQuestions([]);
    setConversationCount(0);
    setQuery('');
  };
  const dummyRef = useRef(null);
  useEffect(() => {
    if (!isLoading) {
      dummyRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isLoading]);

  return (
    <Box
      sx={{
        overflowY: 'auto', // Add vertical scroll if needed
        padding: '12px', // Add padding for content
        borderRadius: 1,
        backgroundColor: '#fff',
        boxShadow: 'none',
        width: '100%',
        mx: 'auto',
        border: '1px solid #ddd',
        display: 'flex',
        flexGrow: 1,
        flexDirection: 'column',
      }}
    >
      <Typography variant="h6" align="center" gutterBottom sx={{ color: '#5f6368' }}>
        AI Chatbot
      </Typography>
      {limitReached && (
        <Alert severity="info" sx={{ mb: 2 }}>
          Conversation limit reached. Please start a new chat.
        </Alert>
      )}
      <Stack direction="column" flexGrow={1} sx={{ overflowY: 'auto', height: 532 }}>
        {chatHistory.map((message, index) => (
          <ChatMessage key={index} message={message} />
        ))}
        {isLoading && (
          <Box
            sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <CircularProgress size={32} />
          </Box>
        )}
        <div ref={dummyRef} />
      </Stack>


      {!limitReached && (
        <>
          {followUpQuestions.length > 0 && (
            <Box sx={{ mt: 1, display: 'flex', gap: '10px', overflowX: 'auto' }}>
              {followUpQuestions.map((question, index) => (
                <FollowUpQuestion
                  key={index}
                  question={question}
                  onClick={handleFollowUpClick}
                />
              ))}
            </Box>
          )}
          <Box sx={{
            display: 'flex',
            gap: 1,
            mt: 1,
            position: 'sticky',
            bottom: 0,
            backgroundColor: '#fff', // Set background color if needed
            padding: '8px', // Adjust padding as needed
          }}>
            <TextField
              fullWidth
              variant="outlined"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type your message..."
            />
            <SendIconComponent onClick={handleSend} />
          </Box>
        </>
      )}
      {limitReached && (
        <Button
          variant="contained"
          color="primary"
          onClick={startNewChat}
          sx={{
            borderRadius: '20%',
            minWidth: 0, // Reduce minimum width to fit the icon
            '&:hover': {
              backgroundColor: '#0078d4', // Lighter blue on hover
            },
          }}
        >
          Start New Chat
        </Button>
      )}
    </Box>
  );
}

export default Chat;
