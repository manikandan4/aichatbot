// src/muiTheme.js

import { createTheme } from '@mui/material/styles';

const theme = createTheme({
    palette: {
        mode: 'light',
        primary: {
          main: '#143f8c',
        },
        secondary: {
          main: '#f2f4f8',
          contrastText :'#003ea9'
        },
      },
});

export default theme;
