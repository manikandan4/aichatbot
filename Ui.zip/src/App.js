// src/App.js

import React from 'react';
import { ThemeProvider } from '@mui/material/styles';
import { Container, CssBaseline } from '@mui/material';
import Header from './components/Header';
import Footer from './components/Footer';
import Chat from './components/Chat';
import theme from './muiTheme'; 

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container maxWidth="lg">
        <Header />
        <Chat />
        <Footer />
      </Container>
    </ThemeProvider>
  );
}

export default App;
