# Backend API
1. Create virtual environment
```
cd backend
python3 -m venv .venv
source .venv/bin/activate
```

2. Install Python libraries
```
pip install -r requirements.txt

```
3. To test local, execute below. Change the port number as required.
```
uvicorn main:app --host 0.0.0.0 --port 8444 --reload  
```

4. To build dockerfile and run via container
```
docker build -t aichatbot_api .
docker run -d --name aichatbot_api_container -p 8444:8444 aichatbot_api

```

# Frontend chatbot
1. Install dependencies
```
cd chatbot-ui
npm install
```

2. To run locally 
```
npm start

```
3. To build dockerfile and run via container
```
docker build -t aichatbot_ui .
docker run -d --name aichatbot_ui_container -p 8443:8443 aichatbot_ui
```
