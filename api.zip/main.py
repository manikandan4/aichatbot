import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import logging

# Import routers
from routers import chat

# Load environment variables
load_dotenv()

# Initialize the FastAPI app
app = FastAPI(
    title="LLM Chatbot API",
    description="An API for an LLM-based chatbot that provides responses and follow-up questions",
    version="1.0.0"
)

# Configure logging (optional levels: DEBUG, INFO, WARNING, ERROR, CRITICAL)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Set up CORS middleware with production-ready configuration
origins = os.getenv("ALLOWED_ORIGINS", "").split(",")  # Allow empty string for flexibility
if origins == ["*"]:
    logger.warning("CORS is currently unrestricted. Consider restricting origins in production.")
logger.info(f"Origins value : {origins}")

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(chat.router)

# Health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy"}
