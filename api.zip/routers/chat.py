# routers/chat.py

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from openai import OpenAI
from dotenv import load_dotenv
import os
import logging

# Initialize router
router = APIRouter()

# Configure logging
logger = logging.getLogger(__name__)

# Set your OpenAI API key
load_dotenv()
openai_model="gpt-3.5-turbo"
api_key = os.environ.get("OPENAI_API_KEY")
client = OpenAI(api_key = api_key)

class Query(BaseModel):
    query: str = Field(..., example="Tell me about climate change")
    history: list = Field(..., example=[{"role": "user", "content": "Who won the world series in 2020?"}, {"role": "assistant", "content": "The Los Angeles Dodgers won the World Series in 2020."}])
    count: int = Field(..., example=1)

def generate_response(query: Query):
    try:
        messages=[{"role": "system", "content": "You are a helpful assistant. Always provide the response in a well formatted markdown"}]
        messages.extend(query.history)
        messages.append({"role": "user", "content": query.query})

        response = client.chat.completions.create(
            model=openai_model,
            messages=messages,
            max_tokens=800,
            n=1,
            stop=None,
            temperature=0.2,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        logger.error(f"Error generating response: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

def generate_follow_up_questions(query: Query):
    try:
        messages=[]
        messages.extend(query.history)
        instruction ='''suggest exactly three relevant follow-up questions to engage the user further.
        The question should be precise and meaningful. Each question should not more than 10 words.
        The questions should be from user prespective , asking the AI for further clarifications or followup.
        Make sure minimal always 3 question is generated.
        '''
        follow_up_prompt = f"Based on the query: '{query.query}, {instruction}'"
        messages.append({"role": "user", "content": follow_up_prompt})

        response = client.chat.completions.create(
            model=openai_model,
            messages=messages,
            max_tokens=200,
            n=1,
            stop=None,
            temperature=0.5,
            top_p=0.5  # Set a high top_p value for more unique choices
        )
        questions = response.choices[0].message.content.strip().splitlines()  # Split by newlines
        return questions
    except Exception as e:
        logger.error(f"Error generating follow-up questions: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/chat")
async def chat(query: Query):

    user_query = query.query
    history = query.history
    count = query.count
    logger.info(f"Input request message : {user_query}")
    logger.info(f"Input history  : {history}")

    if not user_query:
        raise HTTPException(status_code=400, detail="No query provided")

    if count > 10:
        return {
            'response': "Conversation limit reached. Please start a new chat.",
            'follow_up_questions': [],
            'history': [],
            'count': 0
        }

    # Generate response from LLM
    response = generate_response(query)

    # Append the latest response to history
    #new_history = history + [{"role": "user", "content": user_query}, {"role": "assistant", "content": response}]
    new_history = history.copy()
    new_history.extend([{"role": "user", "content": user_query}, {"role": "assistant", "content": response}])

    # Generate follow-up questions
    follow_up_questions = generate_follow_up_questions(query)
    logger.info(f"Chat respone : {response}")
    logger.info(f"followup questions response : {follow_up_questions}")
    logger.info(f"new history : {new_history}")
    logger.info(f"new count : {count + 1}")
    return {
        'response': response,
        'follow_up_questions': follow_up_questions,
        'history': new_history,
        'count': count + 1
    }
